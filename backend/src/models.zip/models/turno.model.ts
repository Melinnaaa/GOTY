import { Model, DataTypes } from 'sequelize';
import sequelize from '../db/connection';
import Empleado from './empleado.model';

class Turno extends Model {
  public id!: number;
  public fecha!: Date;
  public RutEmpleado!: string;
}

Turno.init({
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  fecha: {
    type: DataTypes.DATEONLY,
    allowNull: false,
  },
  RutEmpleado: {
    type: DataTypes.STRING(12),
    allowNull: false,
    references: {
      model: Empleado,
      key: 'Rut',
    },
  },
}, {
  sequelize,
  tableName: 'Turno',
  timestamps: false,
});

Turno.belongsTo(Empleado, { foreignKey: 'RutEmpleado' });

export default Turno;
